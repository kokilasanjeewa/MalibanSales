import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PurchaseorderapproveComponent } from './purchaseorderapprove.component';

describe('PurchaseorderapproveComponent', () => {
  let component: PurchaseorderapproveComponent;
  let fixture: ComponentFixture<PurchaseorderapproveComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PurchaseorderapproveComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PurchaseorderapproveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
