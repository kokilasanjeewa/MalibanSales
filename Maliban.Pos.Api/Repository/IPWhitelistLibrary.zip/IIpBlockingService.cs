﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Maliban.Pos.Api.Repository
{
    public interface IIpBlockingService
    {
        bool IsBlocked(IPAddress ipAddress);
    }
}
