﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Maliban.Pos.Api.Repository
{
    public class IpBlockingService : IIpBlockingService
    {
        private readonly IPWhitelistLibrary_safeList;
   public IpBlockingService(IOptions<IPWhitelistLibrary> safeList)
        {
            _safeList = safeList.Value;
        }
        public bool IsBlocked(IPAddress ipAddress, ProviderTypes? provider)
        {
            List<string>? whiteListIPList = _safeList.WhiteList;

            if (whiteListIPList is null) return false;
            bool isIPWhitelisted = whiteListIPList is not null && whiteListIPList.Where(ip => IPAddress.Parse(ip).Equals(ipAddress)).Any();

            return isIPWhitelisted;
        }
    }
}
