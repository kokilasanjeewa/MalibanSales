﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Maliban.Pos.Api.Repository
{
    public class IPWhitelistLibrary
    {
        public List<string> WhiteList { get; set; }
    }
}
