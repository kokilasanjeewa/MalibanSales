﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Maliban.Pos.Api.Migrations
{
    public partial class initialdb67 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
  /*          migrationBuilder.DropForeignKey(
                name: "FK_StockAdjustmentDetails_Prices_PriceId",
                table: "StockAdjustmentDetails");

            migrationBuilder.CreateTable(
                name: "StockTransferHeaders",
                columns: table => new
                {
                    StockTransferHeaderId = table.Column<long>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CreateDate = table.Column<DateTime>(nullable: false),
                    ModifiedDate = table.Column<DateTime>(nullable: false),
                    CreatedBy = table.Column<string>(maxLength: 100, nullable: false),
                    ModifiedBy = table.Column<string>(maxLength: 100, nullable: true),
                    Active = table.Column<bool>(nullable: false),
                    IsDeleted = table.Column<bool>(nullable: false),
                    StockTransferHeaderUid = table.Column<string>(nullable: false),
                    StockTransferHeaderFactoryId = table.Column<int>(nullable: false),
                    StockTransferHeaderReferenceNo = table.Column<string>(nullable: false),
                    TotalCost = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalDiscountAmount = table.Column<decimal>(type: "decimal(18, 2)", nullable: true),
                    TotalBillAmount = table.Column<decimal>(type: "decimal(18, 2)", nullable: true),
                    StoreId = table.Column<long>(nullable: true),
                    BranchLocationId = table.Column<int>(nullable: false),
                    TransferBranchLocationId = table.Column<int>(nullable: false),
                  //  TransferBranchLocationBranchLocationId = table.Column<int>(nullable: true),
                    Id = table.Column<int>(nullable: false),
                    PaymentMethodId = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_StockTransferHeaders", x => x.StockTransferHeaderId);
                    table.ForeignKey(
                        name: "FK_StockTransferHeaders_AspNetUsers_Id",
                        column: x => x.Id,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_StockTransferHeaders_PaymentMethods_PaymentMethodId",
                        column: x => x.PaymentMethodId,
                        principalTable: "PaymentMethods",
                        principalColumn: "PaymentMethodId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_StockTransferHeaders_Stores_StoreId",
                        column: x => x.StoreId,
                        principalTable: "Stores",
                        principalColumn: "StoreId",
                        onDelete: ReferentialAction.Restrict);
*//*                    table.ForeignKey(
                        name: "FK_StockTransferHeaders_BranchLocations_TransferBranchLocationBranchLocationId",
                        column: x => x.TransferBranchLocationBranchLocationId,
                        principalTable: "BranchLocations",
                        principalColumn: "BranchLocationId",
                        onDelete: ReferentialAction.Restrict);*//*
                    table.ForeignKey(
                        name: "FK_StockTransferHeaders_BranchLocations_TransferBranchLocationId",
                        column: x => x.TransferBranchLocationId,
                        principalTable: "BranchLocations",
                        principalColumn: "BranchLocationId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "StockTransferDetails",
                columns: table => new
                {
                    StockTransferDetailId = table.Column<long>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CreateDate = table.Column<DateTime>(nullable: false),
                    ModifiedDate = table.Column<DateTime>(nullable: false),
                    CreatedBy = table.Column<string>(maxLength: 100, nullable: false),
                    ModifiedBy = table.Column<string>(maxLength: 100, nullable: true),
                    Active = table.Column<bool>(nullable: false),
                    IsDeleted = table.Column<bool>(nullable: false),
                    StockTransferDetailUid = table.Column<string>(nullable: true),
                    TransactionDetailId = table.Column<long>(nullable: false),
                    ProductId = table.Column<long>(nullable: false),
                    PriceId = table.Column<long>(nullable: false),
                    iDocID = table.Column<long>(nullable: false),
                    cDocNo = table.Column<string>(maxLength: 50, nullable: true),
                    dDocDate = table.Column<DateTime>(nullable: false),
                    ProductExpireDate = table.Column<DateTime>(nullable: false),
                    cDocType = table.Column<int>(maxLength: 5, nullable: false),
                    cExtRefNum = table.Column<string>(maxLength: 20, nullable: true),
                    dQuantity = table.Column<decimal>(nullable: false),
                    dIssueQuantity = table.Column<decimal>(nullable: false),
                    dTransferQuantity = table.Column<decimal>(nullable: false),
                    dNetQuantity = table.Column<decimal>(nullable: false),
                    ApproveQuantity = table.Column<decimal>(nullable: false),
                    cApprovalType = table.Column<int>(maxLength: 10, nullable: false),
                    dCostPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    dSalePrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    Barcode = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    ProductName = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    StockTransferHeaderId = table.Column<long>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_StockTransferDetails", x => x.StockTransferDetailId);
                    table.ForeignKey(
                        name: "FK_StockTransferDetails_Prices_PriceId",
                        column: x => x.PriceId,
                        principalTable: "Prices",
                        principalColumn: "PriceId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_StockTransferDetails_Products_ProductId",
                        column: x => x.ProductId,
                        principalTable: "Products",
                        principalColumn: "ProductId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_StockTransferDetails_StockTransferHeaders_StockTransferHeaderId",
                        column: x => x.StockTransferHeaderId,
                        principalTable: "StockTransferHeaders",
                        principalColumn: "StockTransferHeaderId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_StockTransferDetails_PriceId",
                table: "StockTransferDetails",
                column: "PriceId");

            migrationBuilder.CreateIndex(
                name: "IX_StockTransferDetails_ProductId",
                table: "StockTransferDetails",
                column: "ProductId");

            migrationBuilder.CreateIndex(
                name: "IX_StockTransferDetails_StockTransferHeaderId",
                table: "StockTransferDetails",
                column: "StockTransferHeaderId");

            migrationBuilder.CreateIndex(
                name: "IX_StockTransferHeaders_Id",
                table: "StockTransferHeaders",
                column: "Id");

            migrationBuilder.CreateIndex(
                name: "IX_StockTransferHeaders_PaymentMethodId",
                table: "StockTransferHeaders",
                column: "PaymentMethodId");

            migrationBuilder.CreateIndex(
                name: "IX_StockTransferHeaders_StoreId",
                table: "StockTransferHeaders",
                column: "StoreId");

*//*            migrationBuilder.CreateIndex(
                name: "IX_StockTransferHeaders_TransferBranchLocationBranchLocationId",
                table: "StockTransferHeaders",
                column: "TransferBranchLocationBranchLocationId");*//*

            migrationBuilder.CreateIndex(
                name: "IX_StockTransferHeaders_TransferBranchLocationId",
                table: "StockTransferHeaders",
                column: "TransferBranchLocationId");

            migrationBuilder.AddForeignKey(
                name: "FK_StockAdjustmentDetails_Prices_PriceId",
                table: "StockAdjustmentDetails",
                column: "PriceId",
                principalTable: "Prices",
                principalColumn: "PriceId",
                onDelete: ReferentialAction.Restrict);*/
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
          /*  migrationBuilder.DropForeignKey(
                name: "FK_StockAdjustmentDetails_Prices_PriceId",
                table: "StockAdjustmentDetails");

            migrationBuilder.DropTable(
                name: "StockTransferDetails");

            migrationBuilder.DropTable(
                name: "StockTransferHeaders");

            migrationBuilder.AddForeignKey(
                name: "FK_StockAdjustmentDetails_Prices_PriceId",
                table: "StockAdjustmentDetails",
                column: "PriceId",
                principalTable: "Prices",
                principalColumn: "PriceId",
                onDelete: ReferentialAction.Cascade);*/
        }
    }
}
