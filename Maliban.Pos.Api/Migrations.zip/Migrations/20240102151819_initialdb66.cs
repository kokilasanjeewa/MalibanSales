﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Maliban.Pos.Api.Migrations
{
    public partial class initialdb66 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
        /*    migrationBuilder.AddForeignKey(
                name: "FK_StockMovementHeaders_BranchLocations_BranchLocationId",
                table: "StockMovementHeaders",
                column: "BranchLocationId",
                principalTable: "BranchLocations",
                principalColumn: "BranchLocationId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_StockMovementHeaders_Stores_StoreId",
                table: "StockMovementHeaders",
                column: "StoreId",
                principalTable: "Stores",
                principalColumn: "StoreId",
                onDelete: ReferentialAction.Restrict);*/

    /*        migrationBuilder.AddForeignKey(
                name: "FK_StockTransferDetails_Prices_PriceId",
                table: "StockTransferDetails",
                column: "PriceId",
                principalTable: "Prices",
                principalColumn: "PriceId",
                onDelete: ReferentialAction.Cascade);*/

         /*   migrationBuilder.AddForeignKey(
                name: "FK_StockTransferDetails_Products_ProductId",
                table: "StockTransferDetails",
                column: "ProductId",
                principalTable: "Products",
                principalColumn: "ProductId",
                onDelete: ReferentialAction.Cascade);*/

/*            migrationBuilder.AddForeignKey(
                name: "FK_StockTransferDetails_StockTransferHeaders_StockTransferHeaderId",
                table: "StockTransferDetails",
                column: "StockTransferHeaderId",
                principalTable: "StockTransferHeaders",
                principalColumn: "StockTransferHeaderId",
                onDelete: ReferentialAction.Cascade);*/

            migrationBuilder.AddForeignKey(
                name: "FK_StockTransferHeaders_AspNetUsers_Id",
                table: "StockTransferHeaders",
                column: "Id",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_StockTransferHeaders_Stores_StoreId",
                table: "StockTransferHeaders",
                column: "StoreId",
                principalTable: "Stores",
                principalColumn: "StoreId",
                onDelete: ReferentialAction.Restrict);

/*            migrationBuilder.AddForeignKey(
                name: "FK_StockTransferHeaders_Suppliers_SupplierId",
                table: "StockTransferHeaders",
                column: "SupplierId",
                principalTable: "Suppliers",
                principalColumn: "SupplierId",
                onDelete: ReferentialAction.Cascade);*/

     /*       migrationBuilder.AddForeignKey(
                name: "FK_StockTransferHeaders_BranchLocations_TransferBranchLocationId",
                table: "StockTransferHeaders",
                column: "TransferBranchLocationId",
                principalTable: "BranchLocations",
                principalColumn: "BranchLocationId",
                onDelete: ReferentialAction.Restrict);*/

/*            migrationBuilder.AddForeignKey(
                name: "FK_StockTransferHeaders_Suppliers_TransferSupplierId",
                table: "StockTransferHeaders",
                column: "TransferSupplierId",
                principalTable: "Suppliers",
                principalColumn: "SupplierId",
                onDelete: ReferentialAction.Restrict);*/
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
          /*  migrationBuilder.DropForeignKey(
                name: "FK_StockMovementHeaders_BranchLocations_BranchLocationId",
                table: "StockMovementHeaders");

            migrationBuilder.DropForeignKey(
                name: "FK_StockMovementHeaders_Stores_StoreId",
                table: "StockMovementHeaders");
*/
  /*          migrationBuilder.DropForeignKey(
                name: "FK_StockTransferDetails_Prices_PriceId",
                table: "StockTransferDetails");

            migrationBuilder.DropForeignKey(
                name: "FK_StockTransferDetails_Products_ProductId",
                table: "StockTransferDetails");

            migrationBuilder.DropForeignKey(
                name: "FK_StockTransferDetails_StockTransferHeaders_StockTransferHeaderId",
                table: "StockTransferDetails");

            migrationBuilder.DropForeignKey(
                name: "FK_StockTransferHeaders_AspNetUsers_Id",
                table: "StockTransferHeaders");

            migrationBuilder.DropForeignKey(
                name: "FK_StockTransferHeaders_Stores_StoreId",
                table: "StockTransferHeaders");

            migrationBuilder.DropForeignKey(
                name: "FK_StockTransferHeaders_Suppliers_SupplierId",
                table: "StockTransferHeaders");

            migrationBuilder.DropForeignKey(
                name: "FK_StockTransferHeaders_BranchLocations_TransferBranchLocationBranchLocationId",
                table: "StockTransferHeaders");

            migrationBuilder.DropForeignKey(
                name: "FK_StockTransferHeaders_BranchLocations_TransferBranchLocationId",
                table: "StockTransferHeaders");

            migrationBuilder.DropForeignKey(
                name: "FK_StockTransferHeaders_Suppliers_TransferSupplierId",
                table: "StockTransferHeaders");*/
        }
    }
}
